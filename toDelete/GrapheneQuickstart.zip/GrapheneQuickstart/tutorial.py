from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import Column, Integer, String

engine = create_engine("sqlite:///pythonsqlite.db")
Session = sessionmaker(bind=engine)
session = Session()
Base = declarative_base()

class Words(Base):

    __tablename__='words'

    id = Column(Integer, primary_key=True)
    hiragana = Column(String)
    katakana = Column(String)
    kanji = Column(String)
    resource = Column(String)

    def __repr__(self):
        return f'{self.hiragana}, {self.katakana}, {self.kanji}, {self.resource}'

# Base.metadata.create_all(engine)

# word = Words(hiragana='Hiragana1', katakana='Katakana1', kanji='Kanji1', resource='Resource1')
# word2 = Words(hiragana='Hiragana2', katakana='Katakana2', kanji='Kanji2', resource='Resource2')
# session.add(word)
# session.add(word2)
# session.commit()

query = session.query(Words).all()

print(query)
