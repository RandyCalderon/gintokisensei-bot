import graphene
from graphene import relay
from graphene_sqlalchemy import SQLAlchemyObjectType, SQLAlchemyConnectionField
from models import db_session, Words as WordsModel


class Words(SQLAlchemyObjectType):
    class Meta:
        model = WordsModel
        interfaces = (relay.Node, )

class WordsConnection(relay.Connection):
    class Meta:
        node = Words

class Query(graphene.ObjectType):
    node = relay.Node.Field()

    all_words = SQLAlchemyConnectionField(WordsConnection)

schema = graphene.Schema(query=Query)
