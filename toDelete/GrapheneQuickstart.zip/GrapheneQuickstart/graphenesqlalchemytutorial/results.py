from schema import schema
from db import session

query = '''
    query {
      words {
        hiragana,
        kanji,
        resource
        level =
      }
    }
'''
result = schema.execute(query, context_value={'session': session})
print([dict['hiragana'] for dict in result.data['words']])
