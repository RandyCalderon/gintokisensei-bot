import graphene
from graphene_sqlalchemy import SQLAlchemyObjectType
from models import WordListModel

class WordList(SQLAlchemyObjectType):
    class Meta:
        model = WordListModel
        # use `only_fields` to only expose specific fields ie "name"
        # only_fields = ("name",)
        # use `exclude_fields` to exclude specific fields ie "last_name"
        # exclude_fields = ("last_name",)

class Query(graphene.ObjectType):
    words = graphene.List(WordList)

    def resolve_words(self, info):
        query = WordList.get_query(info)
        print(info)  # SQLAlchemy query
        return query.all()

schema = graphene.Schema(query=Query)
