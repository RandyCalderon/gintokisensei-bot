from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import Column, Integer, String

engine = create_engine("sqlite:///pythonsqlite.db")
Session = sessionmaker(bind=engine)
session = Session()
